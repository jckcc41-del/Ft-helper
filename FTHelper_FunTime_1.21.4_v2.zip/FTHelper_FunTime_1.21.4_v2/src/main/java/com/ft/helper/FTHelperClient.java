package com.ft.helper;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public class FTHelperClient implements ClientModInitializer {

    public static final String KEY_CATEGORY = "category.ft-helper";

    public enum SpecialItem {
        DESORIENT("D", "Дезориентация", new String[]{"дезор", "дезориент"}, GLFW.GLFW_KEY_D),
        YAVNAYA_DUST("Y", "Явная пыль", new String[]{"явная", "пыль"}, GLFW.GLFW_KEY_Y),
        TRAP("T", "Трапка", new String[]{"трап", "ловушк"}, GLFW.GLFW_KEY_T),
        PLAST("P", "Пласт", new String[]{"пласт"}, GLFW.GLFW_KEY_P),
        FIRE_TORNADO("F", "Огненный смерч", new String[]{"смерч", "огнен"}, GLFW.GLFW_KEY_F),
        FREEZE_SNOW("S", "Снежок-заморозка", new String[]{"замороз", "снежок"}, GLFW.GLFW_KEY_S),
        GOD_AURA("G", "Божья аура", new String[]{"аура", "бож"}, GLFW.GLFW_KEY_G);

        private final String codeLetter;
        private final String fullName;
        private final String[] keywords;
        private int boundKey;

        SpecialItem(String codeLetter, String fullName, String[] keywords, int defaultKey) {
            this.codeLetter = codeLetter;
            this.fullName = fullName;
            this.keywords = keywords;
            this.boundKey = defaultKey;
        }

        public String getCodeLetter() { return codeLetter; }
        public String getFullName() { return fullName; }
        public String[] getKeywords() { return keywords; }
        public int getBoundKey() { return boundKey; }
        public void setBoundKey(int boundKey) { this.boundKey = boundKey; }
    }

    public static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.ft-helper.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_INSERT,
                KEY_CATEGORY
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;

            while (openGuiKey.wasPressed()) {
                client.setScreen(new FTHelperScreen(client.currentScreen));
            }

            if (client.currentScreen == null) {
                for (SpecialItem item : SpecialItem.values()) {
                    if (item.getBoundKey() != GLFW.GLFW_KEY_UNKNOWN) {
                        if (InputUtil.isKeyPressed(client.getWindow().getHandle(), item.getBoundKey())) {
                            useSpecialItem(client, item);
                        }
                    }
                }
            }
        });
    }

    private static long lastUseTime = 0;

    public static void useSpecialItem(MinecraftClient client, SpecialItem item) {
        if (client.player == null || client.interactionManager == null) return;

        long now = System.currentTimeMillis();
        if (now - lastUseTime < 250) return;
        lastUseTime = now;

        int originalSlot = client.player.getInventory().selectedSlot;

        int hotbarSlot = findInHotbar(client, item.getKeywords());
        if (hotbarSlot != -1) {
            client.player.getInventory().selectedSlot = hotbarSlot;
            client.interactionManager.interactItem(client.player, Hand.MAIN_HAND);
            client.player.sendMessage(Text.literal("§a[FT Helper] Использован: §e" + item.getFullName()), true);
            return;
        }

        int invSlot = findInInventory(client, item.getKeywords());
        if (invSlot != -1) {
            int syncId = client.player.currentScreenHandler.syncId;

            client.interactionManager.clickSlot(
                    syncId,
                    invSlot,
                    originalSlot,
                    SlotActionType.SWAP,
                    client.player
            );

            client.interactionManager.interactItem(client.player, Hand.MAIN_HAND);
            client.player.sendMessage(Text.literal("§a[FT Helper] Свапнут и использован: §e" + item.getFullName()), true);
        } else {
            client.player.sendMessage(Text.literal("§c[FT Helper] §e" + item.getFullName() + " §cне найден!"), true);
        }
    }

    private static int findInHotbar(MinecraftClient client, String[] keywords) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = client.player.getInventory().getStack(i);
            if (isMatching(stack, keywords)) {
                return i;
            }
        }
        return -1;
    }

    private static int findInInventory(MinecraftClient client, String[] keywords) {
        for (int i = 9; i < 36; i++) {
            ItemStack stack = client.player.getInventory().getStack(i);
            if (isMatching(stack, keywords)) {
                return i;
            }
        }
        return -1;
    }

    private static boolean isMatching(ItemStack stack, String[] keywords) {
        if (stack.isEmpty()) return false;
        String name = stack.getName().getString().toLowerCase();
        for (String kw : keywords) {
            if (name.contains(kw.toLowerCase())) return true;
        }
        return false;
    }
}

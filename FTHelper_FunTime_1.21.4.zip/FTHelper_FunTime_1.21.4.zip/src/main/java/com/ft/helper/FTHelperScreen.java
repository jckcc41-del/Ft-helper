package com.ft.helper;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

public class FTHelperScreen extends Screen {

    private final Screen parent;
    private FTHelperClient.SpecialItem listeningItem = null;
    private final Map<FTHelperClient.SpecialItem, ButtonWidget> bindButtons = new HashMap<>();

    public FTHelperScreen(Screen parent) {
        super(Text.literal("FT Helper - Настройка спец-предметов"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int startY = 50;
        int spacing = 24;
        int index = 0;
        int centerX = this.width / 2;

        for (FTHelperClient.SpecialItem item : FTHelperClient.SpecialItem.values()) {
            int currentY = startY + (index * spacing);
            final FTHelperClient.SpecialItem currentItem = item;

            String keyText = getKeyName(item.getBoundKey());
            ButtonWidget btn = ButtonWidget.builder(Text.literal(keyText), button -> {
                listeningItem = currentItem;
                button.setMessage(Text.literal("> ... <"));
            }).dimensions(centerX + 60, currentY, 70, 20).build();

            bindButtons.put(item, btn);
            this.addDrawableChild(btn);

            index++;
        }

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Готово"), button -> {
            if (this.client != null) {
                this.client.setScreen(this.parent);
            }
        }).dimensions(centerX - 50, startY + (index * spacing) + 10, 100, 20).build());
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listeningItem != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                listeningItem.setBoundKey(GLFW.GLFW_KEY_UNKNOWN);
            } else {
                listeningItem.setBoundKey(keyCode);
            }

            ButtonWidget btn = bindButtons.get(listeningItem);
            if (btn != null) {
                btn.setMessage(Text.literal(getKeyName(listeningItem.getBoundKey())));
            }

            listeningItem = null;
            return true;
        }

        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 20, 0xFFFFFF);

        int startY = 50;
        int spacing = 24;
        int index = 0;
        int centerX = this.width / 2;

        for (FTHelperClient.SpecialItem item : FTHelperClient.SpecialItem.values()) {
            int currentY = startY + (index * spacing) + 5;
            String label = "§e[" + item.getCodeLetter() + "] §f" + item.getFullName();
            context.drawTextWithShadow(this.textRenderer, Text.literal(label), centerX - 130, currentY, 0xFFFFFF);
            index++;
        }

        super.render(context, mouseX, mouseY, delta);
    }

    private String getKeyName(int keyCode) {
        if (keyCode == GLFW.GLFW_KEY_UNKNOWN) return "NONE";
        return InputUtil.Type.KEYSYM.createFromCode(keyCode).getLocalizedText().getString().toUpperCase();
    }

    @Override
    public void close() {
        if (this.client != null) {
            this.client.setScreen(this.parent);
        }
    }
}
